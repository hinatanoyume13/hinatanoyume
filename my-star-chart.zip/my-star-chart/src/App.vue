<script setup>
import StarCanvas from './components/StarCanvas.vue'
</script>

<template>
 
 
    <h1>星を表示するテスト</h1>
 
 
  <div>
    <StarCanvas />
  </div>


</template>

<style scoped>
/* 必要ならスタイルをここに追加 */
</style>
