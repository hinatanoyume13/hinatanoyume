<template>
  <canvas ref="canvas" width="600" height="600" style="border:1px solid #ccc;"></canvas>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const canvas = ref(null)

// サンプルの星データ（RA[°], Dec[°]）
const stars = [
  { ra: 0, dec: 0 },
  { ra: 30, dec: 10 },
  { ra: 60, dec: -20 },
  { ra: 120, dec: 45 },
  { ra: 200, dec: -45 },
  { ra: 330, dec: 0 }
]

function raDecToPolarXY(ra, dec, width, height) {
  const centerX = width / 2
  const centerY = height / 2
  const maxRadius = Math.min(width, height) / 2 - 20

  // 角度（RA）をラジアンに変換（北を上にするため -90°してます）
  const theta = ((ra - 90) / 360) * 2 * Math.PI

  // Decを中心90°→外周-90° にマッピング
  const radius = ((90 - dec) / 180) * maxRadius

  const x = centerX + radius * Math.cos(theta)
  const y = centerY + radius * Math.sin(theta)

  return { x, y }
}

onMounted(() => {
  const ctx = canvas.value.getContext('2d')
  const width = canvas.value.width
  const height = canvas.value.height
  const centerX = width / 2
  const centerY = height / 2
  const maxRadius = Math.min(width, height) / 2 - 20

  // 背景
  ctx.fillStyle = 'black'
  ctx.fillRect(0, 0, width, height)

  // 円形の全天枠を描く
  ctx.strokeStyle = 'white'
  ctx.beginPath()
  ctx.arc(centerX, centerY, maxRadius, 0, Math.PI * 2)
  ctx.stroke()

  // 星を描く
  ctx.fillStyle = 'white'
  stars.forEach(star => {
    const { x, y } = raDecToPolarXY(star.ra, star.dec, width, height)
    ctx.beginPath()
    ctx.arc(x, y, 3, 0, Math.PI * 2)
    ctx.fill()
  })
})
</script>
