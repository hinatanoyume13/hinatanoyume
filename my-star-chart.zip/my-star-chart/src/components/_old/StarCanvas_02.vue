<template>
  <canvas ref="canvas" width="600" height="600" style="border:1px solid #ccc;"></canvas>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const canvas = ref(null)

//複数の星をただ表示する

// サンプルの星データ（赤経[°], 赤緯[°]）
const stars = [
  { ra: 0, dec: 0 },         // 赤道・春分点
  { ra: 30, dec: 10 },
  { ra: 60, dec: -20 },
  { ra: 120, dec: 45 },
  { ra: 200, dec: -45 },
  { ra: 330, dec: 0 }
]

// 座標変換：RA,Dec → canvas座標
function raDecToXY(ra, dec, width, height) {
  const x = (ra / 360) * width
  const y = height / 2 - (dec / 90) * (height / 2)
  return { x, y }
}

onMounted(() => {
  const ctx = canvas.value.getContext('2d')
  const width = canvas.value.width
  const height = canvas.value.height

  // 背景
  ctx.fillStyle = 'black'
  ctx.fillRect(0, 0, width, height)

  // 星を描く
  ctx.fillStyle = 'white'
  stars.forEach(star => {
    const { x, y } = raDecToXY(star.ra, star.dec, width, height)
    ctx.beginPath()
    ctx.arc(x, y, 3, 0, Math.PI * 2)
    ctx.fill()
  })
})
</script>
