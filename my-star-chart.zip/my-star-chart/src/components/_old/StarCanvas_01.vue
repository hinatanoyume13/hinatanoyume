<template>
  <canvas ref="canvas" width="400" height="400" style="border:1px solid #ccc;"></canvas>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const canvas = ref(null)

onMounted(() => {
  const ctx = canvas.value.getContext('2d')
  ctx.fillStyle = 'black'
  ctx.fillRect(0, 0, 400, 400)

  // 星っぽい点を描く
  ctx.fillStyle = 'white'
  ctx.beginPath()
  ctx.arc(200, 200, 3, 0, Math.PI * 2)
  ctx.fill()
})
</script>
